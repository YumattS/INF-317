﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
 
    public partial class Form1 : Form
    {
        
        Stack<double> operacion = new Stack<double>();
        Stack<String> principal = new Stack<string>();
        Stack<int> multiplica = new Stack<int>();
        Stack<int> divide = new Stack<int>();
        Stack<Operacion2> Otra = new Stack<Operacion2>();
        String antiguos = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Button bu = sender as Button;
            textBox1.Text = textBox1.Text + bu.Text;
            if (bu.Text.Equals("="))
            {
                int n = principal.Count();
                String almacena = "";
                for (int i = 0; i < n; i++)
                {
                    String palabra = (string)principal.Pop();
                    if (palabra.Equals("+") || palabra.Equals("-"))
                    {
                        if (multiplica.Count != 0 || divide.Count != 0)
                        {
                            multiplica.Push(Convert.ToInt32(almacena));
                            antiguos = "";

                            double mult = 1;
                            double div = 1;
                            while (multiplica.Count > 0) {
                                mult = mult * multiplica.Pop();
                            }
                            while (divide.Count > 0)
                            {
                                div = div * divide.Pop();
                            }
                            int signo = 0;
                            if (palabra.Equals("+"))
                            {
                                signo = 1;
                            }
                            else {
                                signo = -1;
                            }
                            operacion.Push(Convert.ToDouble(mult/div)*signo);
                            almacena = "";
                        }
                        else
                        {
                            int signo = 0;
                            if (palabra.Equals("+"))
                            {
                                signo = 1;
                            }
                            else
                            {
                                signo = -1;
                            }
                            operacion.Push(Convert.ToDouble(almacena) * signo);
                            almacena = "";
                        }
                    }
                    else if (palabra.Equals("*") || palabra.Equals("/")) {
                        if (palabra.Equals("*")) {
                            multiplica.Push(Convert.ToInt32(almacena));
                        }
                        else {
                            divide.Push(Convert.ToInt32(almacena));
                        }
                        almacena = "";
                        antiguos = palabra;
                    }
                    else {
                        almacena = palabra + almacena;
                    }
                }
                if (!almacena.Equals("")) {
                    if (!antiguos.Equals("")) {
                        multiplica.Push(Convert.ToInt32(almacena));
                        antiguos = "";

                        double mult = 1;
                        double div = 1;
                        while (multiplica.Count > 0)
                        {
                            mult = mult * multiplica.Pop();
                        }
                        while (divide.Count > 0)
                        {
                            div = div * divide.Pop();
                        }
                        Console.WriteLine(mult+" "+div );
                        operacion.Push(Convert.ToDouble(mult / div));
                        almacena = "";
                    }
                    else {
                        operacion.Push(Convert.ToDouble(almacena));
                    }
                    
                }
                Double res = 0;
                foreach (Double numero in operacion) {
                    res = res + numero;
                }
                textBox1.Text = textBox1.Text + "\n" + res;
            }
            else if (bu.Text.Equals("C")) {
                textBox1.Text = textBox1.Text.Substring(0, textBox1.Text.Length - 2);
                principal.Pop();
            }
            else if (bu.Text.Equals("Limpiar")) {
                operacion.Clear();
                principal.Clear();
                textBox1.Text = "";
                multiplica.Clear();
                divide.Clear();
            }
            else
            {
                principal.Push(bu.Text);
            }
        }
    }
}

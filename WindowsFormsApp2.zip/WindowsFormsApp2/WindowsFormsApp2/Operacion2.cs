﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2
{
    public class Operacion2
    {
        public String signo;
        public Stack<int> mul;
        public Stack<int> div;
        public String Signo { get; set; }
        public Stack<int> Mul { get; set; }
        public Stack<int> Div { get; set; }
        public Operacion2(String signo1, Stack<int> mul2,Stack<int> div2)
        {
            signo = signo1;
            this.Mul = mul2;
            this.Div = div2;
        }

    }
}
